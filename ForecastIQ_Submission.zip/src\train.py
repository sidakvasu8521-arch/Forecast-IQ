import os
import pickle
import pandas as pd
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from datetime import datetime

# Import models from our forecasting module structure
class ProphetStyleModel:
    def __init__(self):
        self.scaler = StandardScaler()
        self.model = Ridge(alpha=1.0)
        self.feature_names = []

    def _get_fourier_features(self, dates):
        t = np.array([(d - dates[0]).days for d in dates], dtype=float)
        features = {"trend": t}
        for i in range(1, 4):
            features[f"sin_week_{i}"] = np.sin(2 * np.pi * i * t / 7.0)
            features[f"cos_week_{i}"] = np.cos(2 * np.pi * i * t / 7.0)
        for i in range(1, 6):
            features[f"sin_year_{i}"] = np.sin(2 * np.pi * i * t / 365.25)
            features[f"cos_year_{i}"] = np.cos(2 * np.pi * i * t / 365.25)
        return pd.DataFrame(features)

    def fit(self, dates, y):
        X = self._get_fourier_features(dates)
        self.feature_names = X.columns.tolist()
        X_scaled = self.scaler.fit_transform(X)
        self.model.fit(X_scaled, y)
        self.start_date = dates[0]
        return self

    def predict(self, dates):
        X = self._get_fourier_features(dates)
        X_scaled = self.scaler.transform(X)
        return self.model.predict(X_scaled)


def main():
    features_path = "features.csv"
    if not os.path.exists(features_path):
        print("features.csv not found. Run generate_features.py first.")
        return
        
    df = pd.read_csv(features_path)
    df["Date"] = pd.to_datetime(df["Date"])
    
    channels = df["Channel"].unique()
    
    model_artifact = {
        "prophet_rev": {},
        "prophet_spend": {},
        "xgb_rev": {},
        "xgb_spend": {},
        "lgb_rev": {},
        "lgb_spend": {},
        "std_rev": {},
        "train_ends": {}
    }
    
    for channel in channels:
        df_chan = df[df["Channel"] == channel].sort_values("Date").reset_index(drop=True)
        if len(df_chan) < 14:
            continue
            
        dates = df_chan["Date"].tolist()
        y_rev = df_chan["Revenue"].values
        y_spend = df_chan["Spend"].values
        
        # Fit ProphetStyle
        p_rev = ProphetStyleModel().fit(dates, y_rev)
        p_spend = ProphetStyleModel().fit(dates, y_spend)
        
        # Prep features for tree-based models
        X_list = []
        for i in range(7, len(df_chan)):
            feats = []
            for lag in range(1, 8):
                feats.append(y_rev[i - lag])
                feats.append(y_spend[i - lag])
            feats.append(df_chan.loc[i, "DayOfWeek"])
            feats.append(df_chan.loc[i, "Month"])
            X_list.append(feats)
            
        X = np.array(X_list)
        y_rev_train = y_rev[7:]
        y_spend_train = y_spend[7:]
        
        # Train XGB (fallback style)
        xgb_rev = GradientBoostingRegressor(n_estimators=50, max_depth=4, learning_rate=0.1, random_state=42)
        xgb_rev.fit(X, y_rev_train)
        
        xgb_spend = GradientBoostingRegressor(n_estimators=50, max_depth=4, learning_rate=0.1, random_state=42)
        xgb_spend.fit(X, y_spend_train)
        
        # Train LGB (fallback style)
        lgb_rev = RandomForestRegressor(n_estimators=50, max_depth=4, random_state=42)
        lgb_rev.fit(X, y_rev_train)
        
        lgb_spend = RandomForestRegressor(n_estimators=50, max_depth=4, random_state=42)
        lgb_spend.fit(X, y_spend_train)
        
        # Calculate standard deviation of residuals
        pred_rev = 0.35 * p_rev.predict(dates[7:]) + 0.35 * xgb_rev.predict(X) + 0.30 * lgb_rev.predict(X)
        std_val = np.std(y_rev_train - pred_rev) if len(y_rev_train) > 0 else y_rev.mean() * 0.1
        
        # Save to artifact
        model_artifact["prophet_rev"][channel] = p_rev
        model_artifact["prophet_spend"][channel] = p_spend
        model_artifact["xgb_rev"][channel] = xgb_rev
        model_artifact["xgb_spend"][channel] = xgb_spend
        model_artifact["lgb_rev"][channel] = lgb_rev
        model_artifact["lgb_spend"][channel] = lgb_spend
        model_artifact["std_rev"][channel] = std_val
        model_artifact["train_ends"][channel] = {
            "date": dates[-1],
            "last_revs": list(y_rev[-10:]),
            "last_spends": list(y_spend[-10:])
        }
        
    os.makedirs("./pickle", exist_ok=True)
    with open("./pickle/model.pkl", "wb") as f:
        pickle.dump(model_artifact, f)
        
    print("Trained model successfully saved to ./pickle/model.pkl")

if __name__ == "__main__":
    main()
