import os
import argparse
import pandas as pd
import numpy as np

def clean_and_normalize(dfs):
    cleaned_dfs = []
    
    # 1. Standardize marketing channels
    for name in ["Google Ads", "Meta", "MS Ads"]:
        if name not in dfs or dfs[name].empty:
            continue
            
        df = dfs[name].copy()
        df.columns = [c.strip() for c in df.columns]
        df["Date"] = pd.to_datetime(df["Date"], errors='coerce')
        df = df.dropna(subset=["Date"])
        df["Date"] = df["Date"].dt.strftime("%Y-%m-%d")
        
        for col in ["Spend", "Revenue", "Clicks", "Impressions", "Conversions"]:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0.0).clip(lower=0.0)
            else:
                df[col] = 0.0
                
        channel_label = "Google Ads" if "Google" in name else ("Meta Ads" if "Meta" in name else "MS Ads")
        df["Channel"] = channel_label
        
        df = df.groupby(["Date", "Channel"], as_index=False).agg({
            "Spend": "sum", "Revenue": "sum", "Clicks": "sum", "Impressions": "sum", "Conversions": "sum"
        })
        cleaned_dfs.append(df)
        
    if cleaned_dfs:
        df_daily_all = pd.concat(cleaned_dfs, ignore_index=True)
    else:
        df_daily_all = pd.DataFrame(columns=["Date", "Channel", "Spend", "Revenue", "Clicks", "Impressions", "Conversions"])
        
    # 2. Shopify Integration
    if "Shopify" in dfs and not dfs["Shopify"].empty:
        df_shop = dfs["Shopify"].copy()
        df_shop.columns = [c.strip() for c in df_shop.columns]
        df_shop["Date"] = pd.to_datetime(df_shop["Date"], errors='coerce')
        df_shop = df_shop.dropna(subset=["Date"])
        df_shop["Date"] = df_shop["Date"].dt.strftime("%Y-%m-%d")
        
        sales_col = "Total Sales" if "Total Sales" in df_shop.columns else df_shop.columns[1]
        df_shop["Total_Sales"] = pd.to_numeric(df_shop[sales_col], errors='coerce').fillna(0.0).clip(lower=0.0)
        
        df_shop_daily = df_shop.groupby("Date", as_index=False).agg({"Total_Sales": "sum"})
        
        # Calculate organic baseline
        df_paid_daily = df_daily_all.groupby("Date", as_index=False).agg({"Spend": "sum", "Revenue": "sum", "Conversions": "sum"})
        df_merged = pd.merge(df_shop_daily, df_paid_daily, on="Date", how="left").fillna(0.0)
        df_merged["Organic_Revenue"] = (df_merged["Total_Sales"] - df_merged["Revenue"]).clip(lower=0.0)
        df_merged["Organic_Conversions"] = (df_merged["Total_Sales"] / 80.0).astype(int) - df_merged["Conversions"]
        df_merged["Organic_Conversions"] = df_merged["Organic_Conversions"].clip(lower=0)
        
        organic_rows = []
        for _, row in df_merged.iterrows():
            organic_rows.append({
                "Date": row["Date"], "Channel": "Organic/Direct", "Spend": 0.0, "Revenue": round(row["Organic_Revenue"], 2),
                "Clicks": int(row["Organic_Conversions"] * 10), "Impressions": int(row["Organic_Conversions"] * 100), "Conversions": int(row["Organic_Conversions"])
            })
        if organic_rows:
            df_daily_all = pd.concat([df_daily_all, pd.DataFrame(organic_rows)], ignore_index=True)
            
    return df_daily_all

def engineer_features(df_daily):
    df = df_daily.copy()
    df["Date"] = pd.to_datetime(df["Date"])
    df = df.sort_values(by=["Channel", "Date"]).reset_index(drop=True)
    
    # Ratios
    df["ROAS"] = np.where(df["Spend"] > 0, df["Revenue"] / df["Spend"], 0.0)
    df["CPA"] = np.where(df["Conversions"] > 0, df["Spend"] / df["Conversions"], 0.0)
    df["CPC"] = np.where(df["Clicks"] > 0, df["Spend"] / df["Clicks"], 0.0)
    df["CTR"] = np.where(df["Impressions"] > 0, df["Clicks"] / df["Impressions"], 0.0)
    df["Conversion_Rate"] = np.where(df["Clicks"] > 0, df["Conversions"] / df["Clicks"], 0.0)
    
    # Calendar features
    df["DayOfWeek"] = df["Date"].dt.dayofweek
    df["Month"] = df["Date"].dt.month
    df["Quarter"] = df["Date"].dt.quarter
    df["WeekOfYear"] = df["Date"].dt.isocalendar().week.astype(int)
    df["IsWeekend"] = np.where(df["DayOfWeek"] >= 5, 1, 0)
    
    # Lags & Rolling
    for lag in [1, 7, 14, 30]:
        df[f"Spend_Lag_{lag}"] = df.groupby("Channel")["Spend"].shift(lag).fillna(0.0)
        df[f"Revenue_Lag_{lag}"] = df.groupby("Channel")["Revenue"].shift(lag).fillna(0.0)
        
    for window in [7, 14, 30]:
        df[f"Spend_RollMean_{window}"] = df.groupby("Channel")["Spend"].transform(lambda x: x.rolling(window, min_periods=1).mean())
        df[f"Revenue_RollMean_{window}"] = df.groupby("Channel")["Revenue"].transform(lambda x: x.rolling(window, min_periods=1).mean())
        df[f"Spend_RollStd_{window}"] = df.groupby("Channel")["Spend"].transform(lambda x: x.rolling(window, min_periods=1).std()).fillna(0.0)
        df[f"Revenue_RollStd_{window}"] = df.groupby("Channel")["Revenue"].transform(lambda x: x.rolling(window, min_periods=1).std()).fillna(0.0)
        
    df["Date"] = df["Date"].dt.strftime("%Y-%m-%d")
    return df

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default="./data")
    parser.add_argument("--out", default="features.csv")
    args = parser.parse_args()
    
    files = {
        "Google Ads": "Google Ads.csv",
        "Meta": "Meta.csv",
        "MS Ads": "MS Ads.csv",
        "Shopify": "Shopify.csv",
        "GA4": "GA4.csv"
    }
    
    dfs = {}
    for name, filename in files.items():
        path = os.path.join(args.data_dir, filename)
        # Check case insensitivity / spaces in filenames
        if not os.path.exists(path):
            # Fallback scan for file matching prefix
            for f in os.listdir(args.data_dir):
                if name.lower().replace(" ", "") in f.lower().replace(" ", "") and f.endswith(".csv"):
                    path = os.path.join(args.data_dir, f)
                    break
        if os.path.exists(path):
            dfs[name] = pd.read_csv(path)
            
    if not dfs:
        raise ValueError(f"No marketing data found in {args.data_dir}")
        
    df_daily = clean_and_normalize(dfs)
    df_featured = engineer_features(df_daily)
    
    df_featured.to_csv(args.out, index=False)
    print(f"Features generated: {df_featured.shape[0]} rows saved to {args.out}")

if __name__ == "__main__":
    main()
