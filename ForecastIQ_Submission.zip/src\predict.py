import os
import argparse
import pickle
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler

# Import models from our forecasting module structure
class ProphetStyleModel:
    def __init__(self):
        self.scaler = StandardScaler()
        self.model = Ridge(alpha=1.0)
        self.feature_names = []

    def _get_fourier_features(self, dates):
        t = np.array([(d - dates[0]).days for d in dates], dtype=float)
        features = {"trend": t}
        for i in range(1, 4):
            features[f"sin_week_{i}"] = np.sin(2 * np.pi * i * t / 7.0)
            features[f"cos_week_{i}"] = np.cos(2 * np.pi * i * t / 7.0)
        for i in range(1, 6):
            features[f"sin_year_{i}"] = np.sin(2 * np.pi * i * t / 365.25)
            features[f"cos_year_{i}"] = np.cos(2 * np.pi * i * t / 365.25)
        return pd.DataFrame(features)

    def fit(self, dates, y):
        X = self._get_fourier_features(dates)
        self.feature_names = X.columns.tolist()
        X_scaled = self.scaler.fit_transform(X)
        self.model.fit(X_scaled, y)
        self.start_date = dates[0]
        return self

    def predict(self, dates):
        X = self._get_fourier_features(dates)
        X_scaled = self.scaler.transform(X)
        return self.model.predict(X_scaled)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--features", default="features.csv")
    parser.add_argument("--model", default="./pickle/model.pkl")
    parser.add_argument("--output", default="./output/predictions.csv")
    args = parser.parse_args()
    
    if not os.path.exists(args.features):
        raise ValueError(f"Features file not found: {args.features}")
    if not os.path.exists(args.model):
        raise ValueError(f"Model file not found: {args.model}")
        
    # 1. Load features
    df = pd.read_csv(args.features)
    
    # 2. Load model
    with open(args.model, "rb") as f:
        model_artifact = pickle.load(f)
        
    channels = df["Channel"].unique()
    predictions = []
    
    for channel in channels:
        if channel not in model_artifact["prophet_rev"]:
            continue
            
        p_rev = model_artifact["prophet_rev"][channel]
        p_spend = model_artifact["prophet_spend"][channel]
        xgb_rev = model_artifact["xgb_rev"][channel]
        xgb_spend = model_artifact["xgb_spend"][channel]
        lgb_rev = model_artifact["lgb_rev"][channel]
        lgb_spend = model_artifact["lgb_spend"][channel]
        std_val = model_artifact["std_rev"][channel]
        
        train_end = model_artifact["train_ends"][channel]
        last_date = pd.to_datetime(train_end["date"])
        
        # We project step-by-step for a 30-day horizon
        history_rev = list(train_end["last_revs"])
        history_spend = list(train_end["last_spends"])
        
        for step in range(1, 31):
            f_date = last_date + timedelta(days=step)
            
            # Feature vector construction matching training
            feats = []
            for lag in range(1, 8):
                feats.append(history_rev[-lag])
                feats.append(history_spend[-lag])
            feats.append(f_date.weekday())
            feats.append(f_date.month)
            feats = np.array([feats])
            
            # Predict Spend
            pred_spend_prophet = p_spend.predict([f_date])[0]
            pred_spend_xgb = xgb_spend.predict(feats)[0]
            pred_spend_lgb = lgb_spend.predict(feats)[0]
            pred_spend = max(0.0, 0.35 * pred_spend_prophet + 0.35 * pred_spend_xgb + 0.30 * pred_spend_lgb)
            
            # Predict Revenue
            pred_rev_prophet = p_rev.predict([f_date])[0]
            pred_rev_xgb = xgb_rev.predict(feats)[0]
            pred_rev_lgb = lgb_rev.predict(feats)[0]
            pred_rev = max(0.0, 0.35 * pred_rev_prophet + 0.35 * pred_rev_xgb + 0.30 * pred_rev_lgb)
            
            # Update history state
            history_rev.append(pred_rev)
            history_spend.append(pred_spend)
            
            # Intervals
            p10 = max(0.0, pred_rev - 1.28 * std_val)
            p90 = pred_rev + 1.28 * std_val
            
            roas = round(pred_rev / pred_spend, 2) if pred_spend > 0 else 0.0
            
            predictions.append({
                "Date": f_date.strftime("%Y-%m-%d"),
                "Channel": channel,
                "Revenue_P10": round(p10, 2),
                "Revenue_P50": round(pred_rev, 2),
                "Revenue_P90": round(p90, 2),
                "Spend": round(pred_spend, 2),
                "ROAS": roas
            })
            
    # Save output to CSV
    df_pred = pd.DataFrame(predictions)
    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    df_pred.to_csv(args.output, index=False)
    print(f"Predictions written successfully: {df_pred.shape[0]} rows saved to {args.output}")

if __name__ == "__main__":
    main()
